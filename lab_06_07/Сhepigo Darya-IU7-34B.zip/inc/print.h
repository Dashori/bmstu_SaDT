#ifndef PRINT_H
#define PRINT_H

#include <stdio.h>
#include <stdlib.h>

void print_info(void);
void print_menu(void);

#endif
